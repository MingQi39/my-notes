export const mockGenerateData = () => {
  // Very naive mock: produce a plan or summary depending on system
  if ((system || "").includes("Plan-and-Execute")) {
    const plan = {
      steps: [
        { step: "获取当前时间", action: "get_clock" },
        {
          step: "获取城市温度",
          action: "get_temperature",
          args: { city: "San Francisco" },
        },
        {
          step: "写入报告到文件",
          action: "write_file",
          args: { file: "tmp/report.txt", content: "时间与温度报告" },
        },
        {
          step: "列出 tmp 目录",
          action: "shell_exec",
          args: { cmd: "ls", args: ["tmp"] },
        },
      ],
    };
    return { text: JSON.stringify(plan) };
  }
  // Summarizer fallback
  return { text: "已根据执行轨迹生成报告并完成任务。" };
};

export const mockChatData = (messages) => {
  // Minimal heuristic ReAct for the default demo task
  const lastUser =
    [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const observationMatch = /Observation:\s*(\{[\s\S]*\})/.exec(lastUser);
  if (!observationMatch) {
    return {
      text: JSON.stringify({
        thought: "先读取 package.json 以统计依赖数量",
        action: "read_file",
        args: { file: "package.json" },
      }),
    };
  }
  try {
    const obs = JSON.parse(observationMatch[1]);
    // After reading file
    if (obs.content && obs.ok) {
      const pkg = JSON.parse(obs.content);
      const depsCount = Object.keys(pkg.dependencies || {}).length;
      const content = `依赖数量: ${depsCount}`;
      return {
        text: JSON.stringify({
          thought: `写入依赖数量(${depsCount})到文件`,
          action: "write_file",
          args: { file: "tmp/deps.txt", content },
        }),
      };
    }
    // After write
    if (obs.message && String(obs.message).includes("wrote")) {
      return {
        text: JSON.stringify({
          thought: "任务完成",
          final: "已写入依赖统计到 tmp/deps.txt",
        }),
      };
    }
    // Fallback
    return {
      text: JSON.stringify({
        thought: "继续",
        final: "任务已完成或无进一步操作",
      }),
    };
  } catch (e) {
    return {
      text: JSON.stringify({
        thought: "解析观察失败，重试",
        action: "read_file",
        args: { file: "package.json" },
      }),
    };
  }
};
