import { generateText } from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { createAzure } from "@ai-sdk/azure";
import { mockChatData, mockGenerateData } from "./mock-data.js";

/**
 * Build a model client from env/config.
 * Supported providers: 'openai', 'azure'.
 */
export function getModelClient(options = {}) {
  const {
    provider = process.env.AI_PROVIDER || "openai",
    apiKey = process.env.AI_PROVIDER_API_KEY,
    baseURL = process.env.OPENAI_BASE_URL || process.env.AZURE_OPENAI_BASE_URL,
    resourceName = process.env.AZURE_OPENAI_RESOURCE_NAME, // for azure
  } = options;

  if (process.env.AI_MOCK === "1") {
    return { client: null, model: null };
  }

  if (!apiKey) {
    throw new Error("Missing API key: set AI_PROVIDER_API_KEY");
  }

  if (provider === "azure") {
    const azure = createAzure({ apiKey, resourceName });
    return { client: azure, model: azure("gpt-5") };
  }

  const openai = createOpenAI({ apiKey, baseURL });
  const modelName = process.env.OPENAI_MODEL || "gpt-4o-mini";
  return { client: openai, model: openai(modelName) };
}

/**
 * Simple text generation wrapper.
 * @param {object} params
 *  - system: system instructions string
 *  - prompt: user prompt string
 *  - schema: optional Zod schema for structured outputs
 */
export async function llmGenerate({ system, prompt, schema, options = {} }) {
  if (process.env.AI_MOCK === "1") {
    return mockGenerateData();
  }
  const { model } = getModelClient(options);
  const result = await generateText({
    model,
    system,
    prompt,
    ...(schema ? { schema } : {}),
  });
  return result;
}

/**
 * Chat-like step with messages array support.
 * messages: [{ role: 'system'|'user'|'assistant', content: string }]
 */
export async function llmChat({ messages, schema, options = {} }) {
  if (process.env.AI_MOCK === "1") {
    return mockChatData(messages);
  }
  const { model } = getModelClient(options);
  const systemMsg =
    messages.find((m) => m.role === "system")?.content || undefined;
  const userMsg = messages
    .filter((m) => m.role === "user" || m.role === "assistant")
    .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
    .join("\n");

  const result = await generateText({
    model,
    system: systemMsg,
    prompt: userMsg,
    ...(schema ? { schema } : {}),
  });
  return result;
}
