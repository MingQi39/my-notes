import { z } from "zod";
import { createTool } from "./types.js";

export const clockTool = createTool({
  name: "get_clock",
  description: "Return current ISO datetime string",
  schema: z.object({}),
  handler: async () => ({ ok: true, now: new Date().toISOString() }),
});

export const fakeTemperatureTool = createTool({
  name: "get_temperature",
  description: "Return a simulated temperature for a city",
  schema: z.object({ city: z.string().default("San Francisco") }),
  handler: async ({ city }) => {
    // simple deterministic pseudo-value based on string hash
    let hash = 0;
    for (let i = 0; i < city.length; i++)
      hash = (hash * 31 + city.charCodeAt(i)) >>> 0;
    const temp = 10 + (hash % 2000) / 100; // 10~30 range approx
    return { ok: true, city, temperatureC: Number(temp.toFixed(1)) };
  },
});

export const fakeAddressTool = createTool({
  name: "get_address",
  description: "Return a simulated address by name ID",
  schema: z.object({ user: z.string().default("alice") }),
  handler: async ({ user }) => {
    const samples = {
      alice: "123 Apple St, Cupertino, CA",
      bob: "9 Market Rd, San Francisco, CA",
      charlie: "42 Aurora Ave, Seattle, WA",
    };
    const address = samples[user] || `100 ${user} Blvd, Metropolis`;
    return { ok: true, user, address };
  },
});
