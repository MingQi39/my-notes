// Tool types and helpers using Zod for schema validation
import { z } from "zod";

export const ToolCallSchema = z.object({
  thought: z.string().optional(),
  action: z.string().optional(),
  args: z.record(z.unknown()).optional(),
  final: z.string().optional(),
});

export function createTool({ name, description, schema, handler }) {
  if (!name || !schema || !handler) {
    throw new Error("Tool requires name, schema, and handler");
  }
  return { name, description, schema, handler };
}
