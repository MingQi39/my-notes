import { z } from "zod";
import { execFile } from "child_process";
import { promisify } from "util";
import { createTool } from "./types.js";

const execFileAsync = promisify(execFile);

// Whitelisted commands for safety
const ALLOWED = new Set(["echo", "ls", "cat", "pwd", "date", "grep", "mkdir"]);

const shellSchema = z.object({
  cmd: z.string(),
  args: z.array(z.string()).optional(),
});

export const shellTool = createTool({
  name: "shell_exec",
  description: "Execute a safe shell command from whitelist",
  schema: shellSchema,
  handler: async ({ cmd, args = [] }) => {
    if (!ALLOWED.has(cmd)) {
      return { ok: false, error: `Command not allowed: ${cmd}` };
    }
    try {
      const { stdout, stderr } = await execFileAsync(cmd, args, {
        encoding: "utf-8",
      });
      return { ok: true, stdout, stderr };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  },
});
