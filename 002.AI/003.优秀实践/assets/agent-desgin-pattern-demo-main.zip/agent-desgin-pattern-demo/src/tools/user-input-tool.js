import { z } from "zod";
import readline from "readline";
import { createTool } from "./types.js";

const userInputSchema = z.object({
  prompt: z.string().default("请输入内容："),
  allowEmpty: z.boolean().default(false),
});

export const userInputTool = createTool({
  name: "user_input",
  description: "在控制台提示用户输入并返回结果",
  schema: userInputSchema,
  handler: async ({ prompt, allowEmpty }) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    try {
      const answer = await new Promise((resolve) =>
        rl.question(`🤖询问：${prompt}\n👨输入：`, resolve),
      );
      const trimmed = answer?.trim() ?? "";
      if (!allowEmpty && trimmed.length === 0) {
        return { ok: false, error: "用户未输入内容" };
      }
      return { ok: true, input: trimmed };
    } finally {
      rl.close();
    }
  },
});
