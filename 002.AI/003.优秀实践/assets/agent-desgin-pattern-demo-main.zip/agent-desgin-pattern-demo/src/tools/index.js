import { readFileTool, writeFileTool } from "./fs-tools.js";
import { shellTool } from "./shell-tools.js";
import {
  clockTool,
  fakeTemperatureTool,
  fakeAddressTool,
} from "./misc-tools.js";
import z from "zod";
import { userInputTool } from "./user-input-tool.js";

const tools = [
  readFileTool,
  writeFileTool,
  shellTool,
  clockTool,
  fakeTemperatureTool,
  fakeAddressTool,
  userInputTool,
];

export function listTools() {
  return tools.map((t) => ({
    name: t.name,
    description: t.description,
    schema: z.toJSONSchema(t.schema),
  }));
}

export function formatToolList() {
  const registry = listTools();
  return registry
    .map((tool) => {
      const keys = Object.keys(tool.schema.properties);
      return `function: ${tool.name}(${keys.join(", ")});
      description: ${tool.description};
      parameters: ${JSON.stringify(tool.schema)};\n\n`;
    })
    .join(", ");
}

export async function callTool(name, args = {}) {
  const tool = tools.find((t) => t.name === name);
  if (!tool) return { ok: false, error: `Unknown tool: ${name}` };
  try {
    const validated = tool.schema.parse(args);
    const res = await tool.handler(validated);
    return res;
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}
