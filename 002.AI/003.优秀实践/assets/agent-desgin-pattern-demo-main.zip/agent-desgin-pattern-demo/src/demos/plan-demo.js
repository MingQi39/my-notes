import { planAndExecute } from "../agents/plan-agent.js";

async function main() {
  const task =
    process.argv.slice(2).join(" ") ||
    "获取当前时间与一个城市温度，写入 tmp/report.txt 并展示文件路径";
  const res = await planAndExecute({ task });
  console.log("FINAL:\n", res.final);
  console.log("PLAN:\n", JSON.stringify(res.plan, null, 2));
  console.log("TRACE:\n", JSON.stringify(res.trace, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
