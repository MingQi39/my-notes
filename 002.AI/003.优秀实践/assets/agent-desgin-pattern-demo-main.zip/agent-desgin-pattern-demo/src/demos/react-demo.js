import { runReAct } from "../agents/react-agent.js";

async function main() {
  const task =
    process.argv.slice(2).join(" ") ||
    "读取 package.json 的依赖数量，然后写入到 tmp/deps.txt";
  const res = await runReAct({ task, maxLoops: 20 });
  console.log("FINAL:", res.final);
  console.log("TRACE:", JSON.stringify(res.trace, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
