import { llmGenerate } from "../llm/provider.js";
import { runReAct } from "./react-agent.js";

const SYSTEM = `You are a professional Planner in a Plan-and-Execute agent architecture.

Your responsibility is to analyze the user's task and produce a clear, minimal,
and executable high-level plan.

Rules and constraints:
- You ONLY generate the plan. You do NOT execute any step.
- You MUST NOT call tools or mention tool names.
- You MUST NOT describe implementation details or low-level actions.
- Each step should describe WHAT needs to be achieved, not HOW it is done.
- Steps must be logically ordered and independent when possible.
- Prefer fewer, clearer steps (3–6 steps).
- Each step should be actionable, unambiguous, and verifiable by an executor.

Output format (strict JSON only):
{
  "steps": [
    { "step": "..." }
  ]
}

Do not include any explanation, commentary, or extra text outside the JSON.`;

export async function planAndExecute({
  task,
  options = {},
  replanOnFailure = true,
  availableTools,
} = {}) {
  const { text } = await llmGenerate({
    system: SYSTEM,
    prompt: `Task: ${task}`,
  });
  let plan;
  try {
    plan = JSON.parse(text);
    console.log("Plan:\n", plan);
  } catch (e) {
    return { final: "Plan parse failed", error: String(e), raw: text };
  }

  const trace = [];
  for (const [idx, s] of plan.steps.entries()) {
    const reactRes = await runReAct({ task: s.step, maxLoops: 10 });

    const observation = reactRes.final
      ? { ok: true, message: reactRes.final }
      : { ok: false, error: "No final from ReAct" };

    trace.push({
      idx: idx + 1,
      step: s.step,
      observation,
      reactTrace: reactRes.trace,
    });

    if (replanOnFailure && !observation.ok) {
      const replanPrompt = `Original task:
      ${task}

      The previous plan failed.

      Failure details:
      - Failed step index: ${idx + 1}
      - Failed step description: ${s.step}
      - Observation at failure:
      ${JSON.stringify(observation)}

      Execution trace so far:
      ${JSON.stringify(reactRes.trace || [])}

      Your task:
      Generate a revised plan that resolves the failure and allows the task to complete successfully.

      Output requirements:
      - Respond with a single valid JSON object only
      - Do NOT include any explanations, comments, or Markdown
      - The JSON must represent a complete revised plan, not a partial patch
      - The revised plan must avoid repeating the failed step in the same form

      Return JSON only.`;
      const { text: newPlanText } = await llmGenerate({
        system: SYSTEM,
        prompt: replanPrompt,
      });
      try {
        const newPlan = JSON.parse(newPlanText);
        plan = newPlan;
        console.log("New Plan:\n", newPlan);
        return await planAndExecute({
          task,
          options,
          replanOnFailure,
          availableTools,
        });
      } catch (e) {
        trace.push({
          idx: idx + 1,
          step: "REPLAN_FAILED",
          error: String(e),
          raw: newPlanText,
        });
      }
    }
  }

  const summaryPrompt = `Given the plan execution trace, summarize final result for task: ${task}.\nTRACE:\n${JSON.stringify(trace, null, 2)}`;
  const { text: final } = await llmGenerate({
    system: "Summarizer",
    prompt: summaryPrompt,
  });
  return { final, plan, trace };
}
